# src/lib/key-functions

These functions may do.. pretty much anything rational that they like.  If they
want keycodes to be sent to the host in an aggregate report, they're responsible
for modifying the appropriate report variables.

-------------------------------------------------------------------------------

Copyright &copy; 2012 Ben Blazak <benblazak.dev@gmail.com>  
Released under The MIT License (MIT) (see "license.md")  
Project located at <https://github.com/benblazak/ergodox-firmware>

